﻿namespace MazeGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.finishLabel = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.finishLabel);
            this.panel1.Controls.Add(this.label88);
            this.panel1.Controls.Add(this.label87);
            this.panel1.Controls.Add(this.label86);
            this.panel1.Controls.Add(this.label85);
            this.panel1.Controls.Add(this.label84);
            this.panel1.Controls.Add(this.label83);
            this.panel1.Controls.Add(this.label82);
            this.panel1.Controls.Add(this.label81);
            this.panel1.Controls.Add(this.label80);
            this.panel1.Controls.Add(this.label79);
            this.panel1.Controls.Add(this.label78);
            this.panel1.Controls.Add(this.label77);
            this.panel1.Controls.Add(this.label76);
            this.panel1.Controls.Add(this.label75);
            this.panel1.Controls.Add(this.label74);
            this.panel1.Controls.Add(this.label73);
            this.panel1.Controls.Add(this.label72);
            this.panel1.Controls.Add(this.label71);
            this.panel1.Controls.Add(this.label70);
            this.panel1.Controls.Add(this.label69);
            this.panel1.Controls.Add(this.label68);
            this.panel1.Controls.Add(this.label67);
            this.panel1.Controls.Add(this.label66);
            this.panel1.Controls.Add(this.label65);
            this.panel1.Controls.Add(this.label64);
            this.panel1.Controls.Add(this.label63);
            this.panel1.Controls.Add(this.label62);
            this.panel1.Controls.Add(this.label61);
            this.panel1.Controls.Add(this.label60);
            this.panel1.Controls.Add(this.label59);
            this.panel1.Controls.Add(this.label58);
            this.panel1.Controls.Add(this.label57);
            this.panel1.Controls.Add(this.label56);
            this.panel1.Controls.Add(this.label55);
            this.panel1.Controls.Add(this.label54);
            this.panel1.Controls.Add(this.label53);
            this.panel1.Controls.Add(this.label52);
            this.panel1.Controls.Add(this.label51);
            this.panel1.Controls.Add(this.label50);
            this.panel1.Controls.Add(this.label49);
            this.panel1.Controls.Add(this.label48);
            this.panel1.Controls.Add(this.label47);
            this.panel1.Controls.Add(this.label46);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label43);
            this.panel1.Controls.Add(this.label42);
            this.panel1.Controls.Add(this.label41);
            this.panel1.Controls.Add(this.label40);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.label39);
            this.panel1.Controls.Add(this.label38);
            this.panel1.Controls.Add(this.label36);
            this.panel1.Controls.Add(this.label35);
            this.panel1.Controls.Add(this.label34);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.label32);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(609, 579);
            this.panel1.TabIndex = 0;
            this.panel1.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // finishLabel
            // 
            this.finishLabel.AutoSize = true;
            this.finishLabel.Location = new System.Drawing.Point(545, 558);
            this.finishLabel.Name = "finishLabel";
            this.finishLabel.Size = new System.Drawing.Size(45, 17);
            this.finishLabel.TabIndex = 178;
            this.finishLabel.Text = "Finish";
            this.finishLabel.MouseEnter += new System.EventHandler(this.finishLabel_MouseEnter);
            // 
            // label88
            // 
            this.label88.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label88.Location = new System.Drawing.Point(545, 499);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(10, 31);
            this.label88.TabIndex = 177;
            this.label88.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label87
            // 
            this.label87.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label87.Location = new System.Drawing.Point(549, 499);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(47, 10);
            this.label87.TabIndex = 176;
            this.label87.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label86
            // 
            this.label86.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label86.Location = new System.Drawing.Point(502, 499);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(10, 72);
            this.label86.TabIndex = 175;
            this.label86.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label85
            // 
            this.label85.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label85.Location = new System.Drawing.Point(459, 461);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(10, 70);
            this.label85.TabIndex = 174;
            this.label85.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label84
            // 
            this.label84.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label84.Location = new System.Drawing.Point(469, 461);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(131, 10);
            this.label84.TabIndex = 173;
            this.label84.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label83
            // 
            this.label83.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label83.Location = new System.Drawing.Point(333, 541);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(10, 24);
            this.label83.TabIndex = 172;
            this.label83.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label82
            // 
            this.label82.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label82.Location = new System.Drawing.Point(247, 469);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(10, 63);
            this.label82.TabIndex = 171;
            this.label82.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label81
            // 
            this.label81.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label81.Location = new System.Drawing.Point(206, 526);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(10, 45);
            this.label81.TabIndex = 170;
            this.label81.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label80
            // 
            this.label80.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label80.Location = new System.Drawing.Point(295, 499);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(80, 10);
            this.label80.TabIndex = 169;
            this.label80.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label79
            // 
            this.label79.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label79.Location = new System.Drawing.Point(374, 426);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(10, 109);
            this.label79.TabIndex = 168;
            this.label79.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label78
            // 
            this.label78.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label78.Location = new System.Drawing.Point(211, 461);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(165, 10);
            this.label78.TabIndex = 167;
            this.label78.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label77
            // 
            this.label77.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label77.Location = new System.Drawing.Point(38, 421);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(255, 10);
            this.label77.TabIndex = 166;
            this.label77.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label76
            // 
            this.label76.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label76.Location = new System.Drawing.Point(123, 508);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(10, 28);
            this.label76.TabIndex = 165;
            this.label76.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label75
            // 
            this.label75.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label75.Location = new System.Drawing.Point(37, 526);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(179, 11);
            this.label75.TabIndex = 164;
            this.label75.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label74
            // 
            this.label74.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label74.Location = new System.Drawing.Point(84, 471);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(10, 28);
            this.label74.TabIndex = 163;
            this.label74.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label73
            // 
            this.label73.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label73.Location = new System.Drawing.Point(38, 471);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(10, 61);
            this.label73.TabIndex = 162;
            this.label73.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label72
            // 
            this.label72.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label72.Location = new System.Drawing.Point(2, 461);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(125, 10);
            this.label72.TabIndex = 161;
            this.label72.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label71
            // 
            this.label71.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label71.Location = new System.Drawing.Point(417, 386);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(10, 183);
            this.label71.TabIndex = 160;
            this.label71.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label70
            // 
            this.label70.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label70.Location = new System.Drawing.Point(549, 382);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(47, 10);
            this.label70.TabIndex = 159;
            this.label70.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label69
            // 
            this.label69.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label69.Location = new System.Drawing.Point(501, 353);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(10, 77);
            this.label69.TabIndex = 158;
            this.label69.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label68
            // 
            this.label68.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label68.Location = new System.Drawing.Point(548, 311);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(10, 42);
            this.label68.TabIndex = 157;
            this.label68.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label67
            // 
            this.label67.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label67.Location = new System.Drawing.Point(548, 343);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(53, 10);
            this.label67.TabIndex = 156;
            this.label67.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label66.Location = new System.Drawing.Point(419, 308);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(139, 10);
            this.label66.TabIndex = 155;
            this.label66.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label65
            // 
            this.label65.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label65.Location = new System.Drawing.Point(374, 347);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(53, 10);
            this.label65.TabIndex = 154;
            this.label65.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label64
            // 
            this.label64.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label64.Location = new System.Drawing.Point(417, 270);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(10, 87);
            this.label64.TabIndex = 153;
            this.label64.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label63
            // 
            this.label63.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label63.Location = new System.Drawing.Point(425, 270);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(128, 10);
            this.label63.TabIndex = 152;
            this.label63.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label62.Location = new System.Drawing.Point(548, 188);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(10, 92);
            this.label62.TabIndex = 151;
            this.label62.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label61
            // 
            this.label61.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label61.Location = new System.Drawing.Point(548, 138);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(52, 14);
            this.label61.TabIndex = 150;
            this.label61.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label60.Location = new System.Drawing.Point(546, 74);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(10, 78);
            this.label60.TabIndex = 149;
            this.label60.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label59.Location = new System.Drawing.Point(502, 73);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(54, 10);
            this.label59.TabIndex = 148;
            this.label59.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label58
            // 
            this.label58.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label58.Location = new System.Drawing.Point(502, 81);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(10, 63);
            this.label58.TabIndex = 147;
            this.label58.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label57
            // 
            this.label57.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label57.Location = new System.Drawing.Point(459, 318);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(10, 77);
            this.label57.TabIndex = 146;
            this.label57.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label56
            // 
            this.label56.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label56.Location = new System.Drawing.Point(459, 139);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(53, 10);
            this.label56.TabIndex = 145;
            this.label56.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label55.Location = new System.Drawing.Point(382, 231);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(129, 10);
            this.label55.TabIndex = 144;
            this.label55.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label54.Location = new System.Drawing.Point(417, 190);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(10, 51);
            this.label54.TabIndex = 143;
            this.label54.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label53
            // 
            this.label53.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label53.Location = new System.Drawing.Point(459, 147);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(10, 51);
            this.label53.TabIndex = 142;
            this.label53.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label52
            // 
            this.label52.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label52.Location = new System.Drawing.Point(502, 5);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(10, 40);
            this.label52.TabIndex = 141;
            this.label52.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label51
            // 
            this.label51.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label51.Location = new System.Drawing.Point(333, 40);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(10, 51);
            this.label51.TabIndex = 140;
            this.label51.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label50
            // 
            this.label50.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label50.Location = new System.Drawing.Point(459, 40);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(10, 62);
            this.label50.TabIndex = 139;
            this.label50.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label49.Location = new System.Drawing.Point(459, 35);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(99, 10);
            this.label49.TabIndex = 138;
            this.label49.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label48
            // 
            this.label48.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label48.Location = new System.Drawing.Point(333, 139);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(10, 46);
            this.label48.TabIndex = 137;
            this.label48.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label47.Location = new System.Drawing.Point(374, 39);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(10, 239);
            this.label47.TabIndex = 136;
            this.label47.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label46.Location = new System.Drawing.Point(417, 8);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(10, 139);
            this.label46.TabIndex = 135;
            this.label46.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label45
            // 
            this.label45.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label45.Location = new System.Drawing.Point(333, 39);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(43, 10);
            this.label45.TabIndex = 134;
            this.label45.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label44.Location = new System.Drawing.Point(374, 306);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(10, 51);
            this.label44.TabIndex = 133;
            this.label44.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label43.Location = new System.Drawing.Point(336, 421);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(222, 10);
            this.label43.TabIndex = 132;
            this.label43.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label42.Location = new System.Drawing.Point(248, 268);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(133, 10);
            this.label42.TabIndex = 131;
            this.label42.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label41.Location = new System.Drawing.Point(207, 348);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(10, 36);
            this.label41.TabIndex = 130;
            this.label41.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label40.Location = new System.Drawing.Point(207, 384);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(177, 10);
            this.label40.TabIndex = 129;
            this.label40.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label26.Location = new System.Drawing.Point(333, 226);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(10, 166);
            this.label26.TabIndex = 128;
            this.label26.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label39.Location = new System.Drawing.Point(119, 2);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(10, 43);
            this.label39.TabIndex = 127;
            this.label39.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label38.Location = new System.Drawing.Point(209, 226);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(92, 10);
            this.label38.TabIndex = 126;
            this.label38.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label36.Location = new System.Drawing.Point(291, 7);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(10, 229);
            this.label36.TabIndex = 125;
            this.label36.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label35.Location = new System.Drawing.Point(84, 190);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(178, 10);
            this.label35.TabIndex = 124;
            this.label35.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label34.Location = new System.Drawing.Point(2, 308);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(81, 11);
            this.label34.TabIndex = 123;
            this.label34.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label12.Location = new System.Drawing.Point(119, 229);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 10);
            this.label12.TabIndex = 122;
            this.label12.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label33.Location = new System.Drawing.Point(248, 39);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(10, 119);
            this.label33.TabIndex = 121;
            this.label33.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label32.Location = new System.Drawing.Point(37, 227);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(10, 90);
            this.label32.TabIndex = 120;
            this.label32.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label30.Location = new System.Drawing.Point(163, 268);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(10, 48);
            this.label30.TabIndex = 119;
            this.label30.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label29.Location = new System.Drawing.Point(207, 40);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(10, 83);
            this.label29.TabIndex = 118;
            this.label29.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label28.Location = new System.Drawing.Point(119, 229);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(10, 88);
            this.label28.TabIndex = 117;
            this.label28.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label15.Location = new System.Drawing.Point(164, 40);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(10, 119);
            this.label15.TabIndex = 116;
            this.label15.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label27.Location = new System.Drawing.Point(291, 139);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(52, 10);
            this.label27.TabIndex = 115;
            this.label27.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label25.Location = new System.Drawing.Point(84, 386);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(90, 10);
            this.label25.TabIndex = 114;
            this.label25.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label24.Location = new System.Drawing.Point(0, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(10, 569);
            this.label24.TabIndex = 113;
            this.label24.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label23.Location = new System.Drawing.Point(0, 563);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(543, 12);
            this.label23.TabIndex = 112;
            this.label23.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label22.Location = new System.Drawing.Point(595, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(10, 575);
            this.label22.TabIndex = 111;
            this.label22.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label21.Location = new System.Drawing.Point(37, 268);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(92, 10);
            this.label21.TabIndex = 110;
            this.label21.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label20.Location = new System.Drawing.Point(77, 149);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(10, 87);
            this.label20.TabIndex = 109;
            this.label20.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label19.Location = new System.Drawing.Point(208, 227);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(10, 91);
            this.label19.TabIndex = 108;
            this.label19.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label18.Location = new System.Drawing.Point(38, 348);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(179, 10);
            this.label18.TabIndex = 107;
            this.label18.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label17.Location = new System.Drawing.Point(216, 307);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(85, 11);
            this.label17.TabIndex = 106;
            this.label17.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label16.Location = new System.Drawing.Point(77, 348);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(10, 48);
            this.label16.TabIndex = 105;
            this.label16.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label14.Location = new System.Drawing.Point(259, 348);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 10);
            this.label14.TabIndex = 104;
            this.label14.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label13.Location = new System.Drawing.Point(37, 348);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(10, 48);
            this.label13.TabIndex = 103;
            this.label13.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label11.Location = new System.Drawing.Point(135, 200);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(10, 35);
            this.label11.TabIndex = 102;
            this.label11.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label10.Location = new System.Drawing.Point(77, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(10, 117);
            this.label10.TabIndex = 101;
            this.label10.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label9.Location = new System.Drawing.Point(37, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(10, 71);
            this.label9.TabIndex = 100;
            this.label9.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label8.Location = new System.Drawing.Point(37, 110);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 10);
            this.label8.TabIndex = 99;
            this.label8.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label7.Location = new System.Drawing.Point(119, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 10);
            this.label7.TabIndex = 98;
            this.label7.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label6.Location = new System.Drawing.Point(164, 396);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(11, 137);
            this.label6.TabIndex = 97;
            this.label6.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label5.Location = new System.Drawing.Point(119, 149);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 10);
            this.label5.TabIndex = 96;
            this.label5.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label4.Location = new System.Drawing.Point(258, 308);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 50);
            this.label4.TabIndex = 95;
            this.label4.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label3.Location = new System.Drawing.Point(37, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 75);
            this.label3.TabIndex = 94;
            this.label3.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label2.Location = new System.Drawing.Point(164, 268);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 10);
            this.label2.TabIndex = 93;
            this.label2.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label1.Location = new System.Drawing.Point(37, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(563, 10);
            this.label1.TabIndex = 92;
            this.label1.MouseEnter += new System.EventHandler(this.wall_MouseEnter);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 603);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Maze Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label finishLabel;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

